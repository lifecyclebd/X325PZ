<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Section_event extends Model
{
    protected $table= 'contents';
}
