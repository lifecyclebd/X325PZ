<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class System_setting extends Model
{
    //
}
