<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doctor_speciality extends Model
{
    //
}
