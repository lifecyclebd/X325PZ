<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doctor_designation extends Model
{
    //
}
