<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class More_about_blood extends Model
{
    //
}
