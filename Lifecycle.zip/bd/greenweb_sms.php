<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="http://sms.greenweb.com.bd/api.php" method="post">
	<input type="text" name="token" placeholder="token" />
	<input type="text" name="to" placeholder="01xxxxxxxxx,01xxxxxxxxx" />
	<textarea class="span11" name="message" id="message" style="position: relative; left: 4%;" ></textarea>
	<button type="submit" name="submit" class="btn btn-success btn-large">Send Message</button>
	</form>
</body>
</html>



